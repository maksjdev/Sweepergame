package Sweeper;

public enum GameState
{
    PLAYED,
    BOMBED,
    WINNER
}
