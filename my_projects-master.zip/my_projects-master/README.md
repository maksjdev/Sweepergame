# my_projects
Игра минер созданная по видеоуроку ITVDN
Game - Sweeper
